﻿using Emgu.CV;
using Emgu.CV.Cuda;
using Emgu.CV.Structure;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace CUDA_ImageProcessing
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_chk_gpu = new System.Windows.Forms.Button();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.pbx_image = new System.Windows.Forms.PictureBox();
            this.btn_read = new System.Windows.Forms.Button();
            this.btn_process = new System.Windows.Forms.Button();
            this.chk_useCuda = new System.Windows.Forms.CheckBox();
            this.lbl_img_size = new System.Windows.Forms.Label();
            this.lbl_elapsed_time = new System.Windows.Forms.Label();
            this.lbl_error = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_image)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_chk_gpu
            // 
            this.btn_chk_gpu.Location = new System.Drawing.Point(25, 37);
            this.btn_chk_gpu.Name = "btn_chk_gpu";
            this.btn_chk_gpu.Size = new System.Drawing.Size(97, 23);
            this.btn_chk_gpu.TabIndex = 0;
            this.btn_chk_gpu.Text = "Check GPU";
            this.btn_chk_gpu.UseVisualStyleBackColor = true;
            this.btn_chk_gpu.Click += new System.EventHandler(this.btn_chk_gpu_Click);
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(25, 67);
            this.txtStatus.Multiline = true;
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(263, 204);
            this.txtStatus.TabIndex = 1;
            // 
            // pbx_image
            // 
            this.pbx_image.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_image.Location = new System.Drawing.Point(294, 67);
            this.pbx_image.Name = "pbx_image";
            this.pbx_image.Size = new System.Drawing.Size(854, 519);
            this.pbx_image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbx_image.TabIndex = 2;
            this.pbx_image.TabStop = false;
            // 
            // btn_read
            // 
            this.btn_read.Location = new System.Drawing.Point(1184, 67);
            this.btn_read.Name = "btn_read";
            this.btn_read.Size = new System.Drawing.Size(75, 23);
            this.btn_read.TabIndex = 3;
            this.btn_read.Text = "Read";
            this.btn_read.UseVisualStyleBackColor = true;
            this.btn_read.Click += new System.EventHandler(this.btn_read_Click);
            // 
            // btn_process
            // 
            this.btn_process.Location = new System.Drawing.Point(1184, 122);
            this.btn_process.Name = "btn_process";
            this.btn_process.Size = new System.Drawing.Size(95, 23);
            this.btn_process.TabIndex = 4;
            this.btn_process.Text = "Process";
            this.btn_process.UseVisualStyleBackColor = true;
            this.btn_process.Click += new System.EventHandler(this.btn_process_Click);
            // 
            // chk_useCuda
            // 
            this.chk_useCuda.AutoSize = true;
            this.chk_useCuda.Location = new System.Drawing.Point(1184, 96);
            this.chk_useCuda.Name = "chk_useCuda";
            this.chk_useCuda.Size = new System.Drawing.Size(95, 20);
            this.chk_useCuda.TabIndex = 5;
            this.chk_useCuda.Text = "Use CUDA";
            this.chk_useCuda.UseVisualStyleBackColor = true;
            // 
            // lbl_img_size
            // 
            this.lbl_img_size.AutoSize = true;
            this.lbl_img_size.ForeColor = System.Drawing.Color.Red;
            this.lbl_img_size.Location = new System.Drawing.Point(294, 604);
            this.lbl_img_size.Name = "lbl_img_size";
            this.lbl_img_size.Size = new System.Drawing.Size(71, 16);
            this.lbl_img_size.TabIndex = 6;
            this.lbl_img_size.Text = "ImageSize";
            // 
            // lbl_elapsed_time
            // 
            this.lbl_elapsed_time.AutoSize = true;
            this.lbl_elapsed_time.ForeColor = System.Drawing.Color.Red;
            this.lbl_elapsed_time.Location = new System.Drawing.Point(1181, 157);
            this.lbl_elapsed_time.Name = "lbl_elapsed_time";
            this.lbl_elapsed_time.Size = new System.Drawing.Size(103, 16);
            this.lbl_elapsed_time.TabIndex = 7;
            this.lbl_elapsed_time.Text = "lblElapsedTime";
            // 
            // lbl_error
            // 
            this.lbl_error.AutoSize = true;
            this.lbl_error.ForeColor = System.Drawing.Color.Red;
            this.lbl_error.Location = new System.Drawing.Point(291, 649);
            this.lbl_error.Name = "lbl_error";
            this.lbl_error.Size = new System.Drawing.Size(0, 20);
            this.lbl_error.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1332, 683);
            this.Controls.Add(this.lbl_error);
            this.Controls.Add(this.lbl_elapsed_time);
            this.Controls.Add(this.lbl_img_size);
            this.Controls.Add(this.chk_useCuda);
            this.Controls.Add(this.btn_process);
            this.Controls.Add(this.btn_read);
            this.Controls.Add(this.pbx_image);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.btn_chk_gpu);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pbx_image)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btn_chk_gpu;
        private TextBox txtStatus;
        private PictureBox pbx_image;
        private Button btn_read;
        private Button btn_process;
        private CheckBox chk_useCuda;
        private Label lbl_img_size;
        private Label lbl_elapsed_time;
        private Label lbl_error;
    }
}

