﻿using Emgu.CV;
using Emgu.CV.Cuda;
using Emgu.CV.Structure;

using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace CUDA_ImageProcessing
{
    public partial class Form1 : Form
    {
        public string fileName = @"images/img1.jpg";
        public Image<Bgr, Byte> i_image;
        public Image<Bgr, Byte> processedImage;

        public Stopwatch stopwatch = new Stopwatch();
        public double m_secondElapsed;
        public Form1()
        {
            InitializeComponent();
        }
        #region Methods
        public void ReadImage()
        {
            //File.Open(@"images/imgblur.jpg",FileMode.Open);
            i_image = new Image<Bgr, Byte>(fileName);
        }
        public void ProcessImage() {
            try
            {
                if (chk_useCuda.Checked)
                {
                    stopwatch.Restart();
                    GpuMat cudImage = new GpuMat();
                    GpuMat resultImage = new GpuMat();

                    cudImage.Upload(i_image);

                    CudaInvoke.BilateralFilter(cudImage, resultImage, 150, 380, 380);
                    processedImage = new Image<Bgr, Byte>(i_image.Width, i_image.Height);
                    resultImage.Download(processedImage);
                    stopwatch.Stop();
                    m_secondElapsed = stopwatch.ElapsedMilliseconds;
                    processedImage.Save(@"images/imgblur.jpg");
                }
                else
                {
                    stopwatch.Restart();
                    processedImage = new Image<Bgr, Byte>(i_image.Width, i_image.Height);
                    CvInvoke.BilateralFilter(i_image, processedImage, 150, 380, 380);
                    stopwatch.Stop();
                    m_secondElapsed = stopwatch.ElapsedMilliseconds;
                    processedImage.Save(@"images/imgblur.jpg");


                }
            }
            
            catch(Exception ex)
            {
                lbl_error.Text = ex.Message;
            }
}
        #endregion
        private async void btn_read_Click(object sender, EventArgs e)
        {
            try
            {
                await Task.Run(() => ReadImage());
            double milPixcel= Convert.ToDouble(i_image.Height *  i_image.Width)/1000000;
            lbl_img_size.Text = "Image Size" + i_image.Width + " X " + i_image.Height+
                "("+milPixcel.ToString("F2")+"million pixceeel";
            pbx_image.Image = i_image.ToBitmap<Bgr,Byte>();
        }
            catch(Exception ex)
            {
                lbl_error.Text = ex.Message;
            }

}

        private async void btn_process_Click(object sender, EventArgs e)
        {
            try
            {
                lbl_elapsed_time.Text = "Elapsed ";

                await Task.Run(() => ProcessImage());

                double elapse_sec = m_secondElapsed / 1000;
                lbl_elapsed_time.Text = "Elapsed " + elapse_sec.ToString("F1") + " Sec ";
                pbx_image.Image = processedImage.ToBitmap<Bgr, Byte>();
            }
            catch(Exception ex)
            {
                lbl_error.Text = ex.Message;
            }

        }

        private void btn_chk_gpu_Click(object sender, EventArgs e)
        {
            try
            {
                if (CudaInvoke.HasCuda)
            {
                txtStatus.Text = CudaInvoke.GetCudaDevicesSummary();
                txtStatus. AppendText("Device Used" + CudaInvoke.GetDevice());
            }
            else
            {
                txtStatus.Text = "No Data ";
                txtStatus.AppendText("Device Used" + CudaInvoke.GetDevice());
                }
        }
            catch(Exception ex)
            {
                lbl_error.Text = ex.Message;
            }
}
    }
}
